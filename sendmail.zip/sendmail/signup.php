<?php

if (isset($_POST['signupbtn'])) {
    echo $name = $_POST['name'];


    $mob = $_POST['mob'];
    $email = $_POST['email'];

    $html = "
    <p> Welcome! $name Thanks for be hacked......  <p/>
    <table>
    <tr>
    <td>Username</td> <td>$name</td>
    </tr>
    <tr><td>Password</td><td>$email</td>
    </tr>
    </table>";

    include('./smtp/PHPMailerAutoload.php');
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    // $mail->SMTPDebug  = 1;
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 587;
    $mail->SMTPSecure = "tls";
    $mail->SMTPAuth = true;
    $mail->Username = "mv.otp@bitbluetech.com";
    $mail->Password = "dextro123";
    $mail->SetFrom("mv.otp@bitbluetech.com");
    $mail->addAddress('07rohitpal@gmail.com');
    $mail->IsHTML(true);
    $mail->Subject = "Welcome in Adi World Localhost";
    $mail->Body = $html;
    $mail->SMTPOptions = array('ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => false
    ));
    if ($mail->send()) {
        echo $msg =  "Mail send";
    } else {
        echo $msg =  "Mail not send";
    }
}
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>
<style>
    label {
        color: #fff;
    }

    @media (min-width: 320px) and (max-width: 600px) {
        .adi_img {
            display: none;
        }
    }
</style>


<!-- contact section start -->
<section class="contact" id="contact" style="background: #000;">
    <div class="max-width">

        <div class="contact-content">
            <div class="div.col-md-12 d-flex justify-content-center">
                <form method="post" action="signup.php" enctype="multipart/form-data">
                    <div style="text-align:center; color:#fff; font-size:2rem; padding:2rem;"><span style="color:red;">Admission</span> Form</div>
                    <div class="field">

                        <input type="text" name="name" id="name" placeholder="Full Name" required>
                    </div>
                    <div class="field mobile">

                        <input type="number" name="mob" id="mob" placeholder="Mobile No." required>
                    </div>
                    <div class="field">

                        <input type="email" name="email" id="email" placeholder="Email" required>
                    </div>


                    <div class="d-flex justify-content-center ">
                        <div>
                            <button type="" name="signupbtn" id="" class="btn btn-danger">Submit</button>
                        </div>
                        <!-- <a href=""><i class="fas fa-key"></i> Forget Password</a> -->

                    </div>
                    <div class="d-flex justify-content-center text-light mt-4" style="margin-top: 2rem;">
                        Already Have a account <a href="login.php" class="pl-2" style="margin: 0px 5px 0px 10px;"> Login here</a><i class="fas fa-hand-point-right"></i>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>